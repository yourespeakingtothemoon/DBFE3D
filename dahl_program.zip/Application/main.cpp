#include "Engine.h"
#include <iostream>

//pos, color, UV
float vertices[] = {
	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	 0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	 0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	 0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	-0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,

	-0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	 0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	-0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	-0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,

	-0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	-0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	-0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	-0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,

	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	 0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	 0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	 0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	 0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,

	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	 0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	 0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	 0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	-0.5f, -0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	-0.5f, -0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,

	-0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,
	 0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,
	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	 0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,
	-0.5f,  0.5f,  0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,
	-0.5f,  0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f
};

int main(int argc, char** argv)
{
	LOG("Application Started...");
	//memory
	dbf::initializeMemory();
	dbf::SetFilePath("../Assets");
	//engine intialize and register
	dbf::Engine::instance().init();
	dbf::Engine::instance().reg();
	LOG("Engine Initialized...");

	//create window
	dbf::g_renderer.generateWindow("DBF3", 800, 600, false);
	LOG("Window Generated...");

	//create framebuffer texture
	auto texture = std::make_shared<dbf::Texture>();
	texture->CreateTexture(1024, 1024); //512
	dbf::g_resourceManager.Add<dbf::Texture>("fb_texture", texture);

	//create framebuffer
	auto framebuffer = dbf::g_resourceManager.Get<dbf::Framebuffer>("framebuffer", "fb_texture");
	framebuffer->unbind();

	// render pass 1 (render to framebuffer) 
	dbf::g_renderer.setViewport(0, 0, framebuffer->getSize().x, framebuffer->getSize().y);
	framebuffer->bind();
	dbf::g_renderer.openFrame();

	// render pass 2 (render to screen) 
	dbf::g_renderer.restoreViewport();
	dbf::g_renderer.openFrame();


	// load scene 
	//std::shared_ptr<dbf::Scene> scene = dbf::g_resourceManager.Get<dbf::Scene>("Scenes/basic.scn");
	auto scene = std::make_unique<dbf::Scene>();

	rapidjson::Document document;
	bool success = dbf::json::Load("scenes/basic.scn", document);
	//bool success = dbf::json::Load("scenes/pixarvivi.scn", document);
	if (!success)
	{
		LOG("error loading scene file %s.", "scenes/basic.scn");
	}
	
	std::vector<dbf::Transform> rando;
	

	bool quit = false;

	while (!quit)
	{
		//update and check for esc key
		dbf::Engine::instance().update();
		if (dbf::g_inputSystem.queryKeyState(dbf::key_escape) == dbf::InpSystem::keyState::Pressed) quit = true;
		//update scene
		scene->update();

		dbf::g_renderer.openFrame();
		scene->preRender(dbf::g_renderer);
		scene->render(dbf::g_renderer);

		dbf::g_renderer.closeFrame();
		
	}
	scene->RemoveAll();
	dbf::Engine::instance().shutdown();

	return 0;
}