#include "MathUtils.h"

namespace math
{
	/*int sqr(int v)
	{
		return v * v;
	}*/
}