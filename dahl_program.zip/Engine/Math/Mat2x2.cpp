#include "Mat2x2.h"

namespace dbf
{
	//10
	//01
	const Mat2x2 Mat2x2::identity{ {1,0},{0,1} };
	//00
	//00
	const Mat2x2 Mat2x2::zero{ {0,0},{0,0} };

}