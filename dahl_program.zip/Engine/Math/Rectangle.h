#pragma once

namespace dbf
{
	struct Rectangle
	{
		int x;
		int y;
		int w;
		int h;
	};
}