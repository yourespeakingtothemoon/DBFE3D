#include "ResourceMgmt.h"

void dbf::ResourceMgmt::init()
{
}

void dbf::ResourceMgmt::shutdown()
{
	m_resources.clear();
}
