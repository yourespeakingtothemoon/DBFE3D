#include "ResourceManager.h"

namespace neu
{
	void neu::ResourceManager::Initialize()
	{
		//
	}

	void neu::ResourceManager::Shutdown()
	{
		//
		m_resources.clear();
	}

}
